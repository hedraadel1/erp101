<?php
return [
	'productcatalogue_module' => 'Product Catalogue Module',
	'catalogue_qr' => 'Catalogue QR',
	'generate_qr' => 'Generate QR',
	'select_business_location' => 'Select Business Location',
	'download_image' => 'Download Image',
	'qr_code_color' => 'Qr code color',
];