<?php

return [
    'name' => 'ProductCatalogue',
    'module_version' => "0.4",
    'pid' => 8
];
